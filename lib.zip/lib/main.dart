import 'package:flutter/material.dart';

void main() {
  runApp(MaterialApp(
    title: 'Ostad Flutter app',
    home: Scaffold(
      appBar: AppBar(
    backgroundColor: Colors.blue,
    title: Text("Ostad Flutter app",style: TextStyle(
      fontSize: 25,
      color: Colors.white
    ),),
    centerTitle: true,
      ),

      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Row(
            children: [
              Text("Text -1",style: TextStyle(
                  fontSize: 25,
                  color: Colors.black
              )),
              Text("Text -1",style: TextStyle(
                  fontSize: 25,
                  color: Colors.black
              )),
            ],
          ),
          Text("Text -1",style: TextStyle(
              fontSize: 25,
              color: Colors.black
          )),
          Text("Text -1",style: TextStyle(
              fontSize: 25,
              color: Colors.black
          )),

        ],
      ) ,
    ),
  ));
}
